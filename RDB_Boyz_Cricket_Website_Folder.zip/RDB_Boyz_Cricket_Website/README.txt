# RDB Boyz Cricket Club Website

## Folder guide

- index.html — Main website file
- assets/css/style.css — Website design and styling
- assets/images/logo — Put your club logo here
- assets/images/team — Put player photos here
- assets/images/gallery — Put match and team photos here
- assets/js — For future interactive features
- pages — For future separate pages such as detailed schedules or player statistics

## Before uploading to GitHub Pages

1. Add your photos to the correct folders.
2. Rename them to match the names used in index.html, or update the image paths.
3. Replace sample player names and match details.
4. Upload the entire folder contents to your GitHub repository.

Important: Keep index.html in the main/root folder.
